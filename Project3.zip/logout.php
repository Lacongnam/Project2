<?php

session_start();
session_destroy();
header("Location: /Project3/ctrangchu/");
?>