<?php
//http://localhost/Project3/ctrangchu/
session_start();
require_once "./mvc/bridge.php";
$myApp = new App();
?>